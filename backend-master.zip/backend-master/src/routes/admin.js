'use strict'
const router = require('express').Router()
const adminCtrl = require('../controller/admin')

// const { authMiddleware } = require('../middlewares/authentication')
// const { authorizationMiddleware } = require('../middlewares/authorization')

router.post('/register', adminCtrl.register)
router.post('/login', adminCtrl.login)
router.post('/forgot-password', adminCtrl.forgotPassword)
router.post('/reset-password', adminCtrl.resetPassword)
router.post('/resent-activation', adminCtrl.resendActivation)
router.get('/users', adminCtrl.getUsers)
router.post('/add/categories', adminCtrl.addCategories)
router.get('/fetch/categories', adminCtrl.fetchCategories)
router.post('/add/product', adminCtrl.addProduct)
router.post('/update/product', adminCtrl.updateProduct)
router.get('/fetch/products', adminCtrl.fetchAllProducts)
router.get('/statastics', adminCtrl.getStatastics)

module.exports = router