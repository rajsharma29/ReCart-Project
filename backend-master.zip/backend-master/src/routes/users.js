'use strict'
const router = require('express').Router()
const usersCtrl = require('../controller/users')
const productCtrl = require('../controller/product')

// const { authMiddleware } = require('../middlewares/authentication')
// const { authorizationMiddleware } = require('../middlewares/authorization')

router.post('/register', usersCtrl.register)
router.post('/login', usersCtrl.login)
router.post('/forgot-password', usersCtrl.forgotPassword)
router.post('/reset-password', usersCtrl.resetPassword)
router.post('/resent-activation', usersCtrl.resendActivation)
router.get('/verify-account', usersCtrl.verifyAccount)
router.get('/products', usersCtrl.getProducts)
router.get('/searchProduct', productCtrl.searchProduct)
router.post('/:type/favourite', productCtrl.addToFavList)
router.post('/product/:productId', productCtrl.getProductById)
router.post('/add/cart', productCtrl.addToCart)
router.get('/my/cart', productCtrl.myCart)
router.get('/remove/cart/:fav_id', productCtrl.removeFromCart)
router.get('/myprofile', usersCtrl.myProfile)
router.post('/update/:user_id', usersCtrl.updateMyProfile)
router.post('/changeImage', usersCtrl.changeProfilePicture)
router.post('/update/address/:addressId/:userId', usersCtrl.updateAddress)
router.get('/purchased', usersCtrl.purchaseHistory)

module.exports = router