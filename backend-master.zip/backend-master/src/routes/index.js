'use strict'
const healthCheck = require('./healthCheck')
const users = require('./users')
const admins = require('./admin')
const payments = require('./payment')

// const connectTimeOut = require('connect-timeout')

// function haltOnTimeOut(req, res, next) {
//     if (!req.timedout) next()
// }

module.exports = (app) => {
    // app.use(connectTimeOut('12000s'))
    // app.use(haltOnTimeOut)
    app.use('/api', healthCheck)
    app.use('/api/user', users)
    app.use('/api/admin', admins)
    app.use('/api/payment', payments)
}

