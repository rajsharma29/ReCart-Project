'use strict'


const configureStripe = require('stripe')
const key = process.env.STRIPE_SECRET_KEY || 'sk_test_uko61CLW3qf0GY7wjI2FVbhD00s1UH771F'
const stripe = configureStripe(key)

module.exports = stripe
