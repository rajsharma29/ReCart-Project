const cloudinary = require('cloudinary').v2
cloudinary.config({
    cloud_name: 'vipul8896',
    api_key: process.env.API_KEY,
    api_secret: process.env.API_SECRET
})

const uploadFile = async (file) => {
    const result = await cloudinary.uploader.upload(file)
    return result
}

module.exports = {
    uploadFile
}