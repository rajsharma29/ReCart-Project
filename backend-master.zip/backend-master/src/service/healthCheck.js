'use strict'

const healthCheck = () => {
    return { msg: 'All Okay!' }
}


module.exports = {
    healthCheck
}