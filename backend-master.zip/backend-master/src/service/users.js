'use strict'
const usersRepo = require('../repositories/users')
const utils = require('../utils/utils')
const { JWTAuth } = require('../utils/jwt-auth')
const jwtAuth = new JWTAuth()
const productsRepo = require('../repositories/products')
const favouritesRepo = require('../repositories/favourite')
const cloudinary = require('../config/cloudinary')
const purchaseHistoryRepo = require('../repositories/purchase-history')

/**
 * 1. Check user with same email exists or not
 * 2. If not exits then register
 * 3. If exists then throw error
 */
const register = async (body) => {
    let { first_name, email, password } = body
    if (!first_name || !email || !password) { throw { msg: 'Name, Email and Password are required to SignUp' } }
    const userExistCheck = await usersRepo.findData({ email }, { _id: 0, email: 1 })
    if (userExistCheck && userExistCheck.length > 0) {
        throw { msg: 'Provided email is alrady registered. Please login' }
    }
    password = utils.encyptData(password)
    const registerUser = await usersRepo.saveData({ first_name, email, password })
    const link = createMailVerificationLink(registerUser.user_code)
    const mailOptions = {
        to: email,
        from: process.env.SMTP_USER,
        subject: 'ReCart - Account Verification',
        html: `Hello ${first_name} <br>Welcome to ReCart. Please click here to activate your <a href=${link}>account</a>`
    }
    await utils.sendEmail(mailOptions)
    return []
}

const createMailVerificationLink = (uCode) => {
    return `http://95.217.233.152:3000/api/user/verify-account?c=${uCode}`
}

/**
 * 1. Check user with provided email is there or not
 * 2. If not, throw error
 * 3. If exists, then check email verified status
 * 4. If 3 failed... then throw error
 * 5. If 3 passed... then check password is matching or not
 * 6. If 5 failed... then throw error
 * 7. If 5 passed... then generate unique token
 * 8. Send final response
 */
const login = async (body) => {
    let { email, password } = body
    if (!email || !password) { throw { msg: 'Email and Password are required to SignIn' } }
    let userData = await usersRepo.findData({ email }, { _id: 0, email: 1, email_verified: 1, password: 1, name: 1, user_role: 1, user_code: 1, is_active: 1 })
    if (!userData || userData.length === 0) {
        throw { msg: 'No any profile found with provided email address' }
    }
    userData = userData[0]
    const passwordFromDb = await utils.decryptData(userData.password)
    if (userData.is_active === false) throw { msg: `This account is temporary disabled. Please contact admin` }
    if (!userData.email_verified) throw { msg: `You haven't verified your email address yet. Please verify` }
    if (password !== passwordFromDb) throw { msg: 'Incorrect password received' }
    const tokenData = {
        email, user_code: userData.user_code, email_status: userData.email_verified, user_role: userData.user_role
    }
    const token = await jwtAuth.createToken(tokenData)
    return { token, user_code: userData.user_code, user_role: userData.user_role, email }
}

const forgotPassword = async (body) => {
    let { email } = body
    if (!email) throw { msg: 'Email is required to send mail for forgot password request' }
    let userData = await usersRepo.findData({ email }, { _id: 0, password: 1, email: 1, email_verified: 1, first_name: 1, user_code: 1, is_active: 1 })
    if (!userData || userData.length === 0) throw { msg: 'No any profile found with provided email address' }
    userData = userData[0]
    let password = await utils.decryptData(userData.password)
    if (userData.is_active === false) throw { msg: `This account is temporary disabled. Please contact admin` }
    if (userData.email_verified === false) throw { msg: `Account associated with this email id is not active. Please resent verification link to activate account` }
    const link = createForgotPasswordLink(userData.user_code)
    const mailOptions = {
        to: email,
        from: process.env.SMTP_USER,
        subject: 'ReCart - Your Password',
        html: `Hello ${userData.first_name} <br>As you forgot your password, we are sending you over mail. Please don't share this mail to anyone. <br> Your password is: ${password}`
    }
    await utils.sendEmail(mailOptions)
    return true
}

const createForgotPasswordLink = (uCode) => {
    return `${process.env.FRONT_RESET_PASSWORD}?c=${uCode}`
}

const resetPassword = async (body) => {
    let { userCode, password } = body
    if (!userCode || !password) throw { msg: `Usercode and Password are required to reset password` }
    password = await utils.encyptData(password)
    await usersRepo.updateData({ user_code: userCode, is_active: true }, { $set: { password } })
    return true
}

const resendActivation = async (body) => {
    let { email } = body
    if (!email) throw { msg: 'Email is required to send mail for resent account activation request' }
    let userData = await usersRepo.findData({ email }, { _id: 0, email: 1, email_verified: 1, name: 1, user_code: 1, is_active: 1 })
    if (!userData || userData.length === 0) throw { msg: 'No any profile found with provided email address' }
    userData = userData[0]
    if (userData.is_active) throw { msg: `This account is already active. No need to send email again.` }
    // send mail to users
    return true
}

const verifyAccount = async (userCode) => {
    if (!userCode) throw { msg: 'Usercode is required to activate acount' }
    await usersRepo.updateData({ user_code: userCode }, { $set: { email_verified: true } })
    return process.env.FRONT_END_LOGIN
}

const fetchProductQuery = () => {
    return [
        { $sort: { created_on: -1 } },
        { $lookup: { from: 'stripe_plans', localField: 'plan_id', foreignField: 'plan_id', as: 'result1' } },
        { $lookup: { from: 'coupons_details', localField: 'coupon_used', foreignField: 'coupon_no', as: 'result2' } },
        { $unwind: "$result1" },
        {
            $unwind: {
                path: "$result2",
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $project: {
                "user_subscriptions_details_id": 1,
                "user_code": 1,
                "started_on": 1,
                "expires_on": 1,
                "plan_id": 1,
                "amount": "$result1.amount",
                "interval": "$result1.interval",
                "plan_name": "$result1.name",
                "plan_type": "$result1.nickname",
                "monthly_limit": "$result1.max_download_count",
                "plan_amount": "$result1.amount",
                "plan_amount_currency": "$result1.currency",
                "coupon_used": 1,
                "coupon_percent_off": { $cond: { if: { $ne: ["$result2.percent_off", undefined] }, then: "$result2.percent_off", else: undefined } }
            }
        }
    ]
}

const getProducts = async (userCode, sF) => {
    const json = {}
    if (sF === "0") json.type = "ecommerce"
    if (sF === "1") json.type = "food"
    const result = await productsRepo.findData(json, {}, { sort: { name: 'asc' } })
    for (let elem of result) {
        if (userCode && elem.product_id) {
            elem.starred = await favouritesRepo.getCount({ product_id: elem.product_id, user_id: userCode, fav: true })
        } else {
            elem.starred = 0
        }
    }
    return result
}

const myProfile = async (userCode) => {
    if (!userCode) { throw { msg: 'Invalid request detected' } }
    const result = await usersRepo.findData({ user_code: userCode, is_active: true })
    return result[0]
}

const changeProfilePicture = async (files, userCode) => {
    if (!userCode) {
        throw { msg: 'Invalid request detected' }
    }
    let url = ''
    if (files && files.file && files.file.tempFilePath) {
        const cloudinaryResult = await cloudinary.uploadFile(files.file.tempFilePath)
        if (!cloudinaryResult || !cloudinaryResult.secure_url) {
            throw { msg: 'We are unable to upload file right now. Please contact admin' }
        }
        url = cloudinaryResult.secure_url
    }
    await usersRepo.updateData({
        user_code: userCode
    }, {
        $set: {
            picture: url
        }
    })
    return url
}

const updateMyProfile = async (body, userCode) => {
    if (body.addresses) {
        await usersRepo.updateData({
            user_code: userCode
        }, {
            $push: {
                addresses: body.addresses
            }
        })
    }
    delete body.addresses
    if (Object.keys(body).length === 0) return { msg: 'Profile Updated Successfully!' }

    const updatejson = {}
    if (body.name) updatejson.name = body.name
    if (body.default_address) updatejson.default_address = body.default_address

    await usersRepo.updateData({
        user_code: userCode
    }, {
        $set: updatejson
    })
    return { msg: 'Profile Updated Successfully!' };
}


const updateAddress = async (body, addressid, userCode) => {
    if (Object.keys(body).length === 0) {
        throw { msg: 'Invalid Object received' }
    }
    const query = {
        user_code: userCode,
        addresses: {
            $elemMatch: {
                address_id: addressid
            }
        }
    }
    const json = {}
    if (body.line1) json['addresses.$.line1'] = body.line1
    if (body.line2) json['addresses.$.line2'] = body.line2
    if (body.city) json['addresses.$.city'] = body.city
    if (body.postal) json['addresses.$.postal'] = body.postal
    if (body.state) json['addresses.$.state'] = body.state
    if (body.country) json['addresses.$.country'] = body.country
    if ('is_active' in body) json['addresses.$.is_active'] = body.is_active
    await usersRepo.updateData(query, { $set: json })
    return { msg: 'Address updated successfully!' }
}

const purchaseHistory = async (userCode) => {
    if (!userCode) {
        throw { msg: 'Usercode is required!' }
    }
    const query = [
        { $match: { user_id: userCode } },
        { $lookup: { from: "products", localField: "product_id", foreignField: "product_id", as: "prodData" } },
        { $unwind: { path: "$prodData", preserveNullAndEmptyArrays: true } },
        {
            $project: {
                product_id: 1,
                favourite_id: 1,
                purchase_history_id: 1,
                user_id: 1,
                units: 1,
                price_per_unit: "$prodData.price_per_unit",
                picture: "$prodData.picture",
                name: "$prodData.name",
                type: "$prodData.type",
                create_on: "$prodData.created_on"
            }
        }
    ]
    const data = await purchaseHistoryRepo.aggregateData(query)
    return data
}

module.exports = {
    register, login, forgotPassword, resetPassword, resendActivation,
    verifyAccount, getProducts,
    myProfile,
    changeProfilePicture,
    updateMyProfile,
    updateAddress,
    purchaseHistory
}