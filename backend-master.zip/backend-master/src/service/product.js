'use strict'
const categoriesRepo = require('../repositories/categories')
const productDataRepo = require('../repositories/products')
const favouritesRepo = require('../repositories/favourite')

const searchProduct = async (extraParams, userCode, sF) => {
    const catData = await categoriesRepo.findData(extraParams.filter, { category_id: 1, _id: 0 }, {})
    const catIds = []
    catData.map(elem => catIds.push(elem.category_id))
    const options = {}
    if (extraParams.offset) {
        options.skip = Number(extraParams.offset)
    }
    if (extraParams.limit) {
        options.limit = Number(extraParams.limit)
    }
    if (extraParams.sort) {
        options.sort = extraParams.sort
    }
    let filters = extraParams.filter['$or']
    filters.push({ parent_cat: { $in: catIds } })
    filters.push({ sub_cat: { $in: catIds } })
    let type = ''
    if (sF === '0') type = 'ecommerce'
    if (sF === '1') type = 'food'
    let query = {}
    query['$or'] = filters
    if(type !== '') query['type'] = type
    const productData = await productDataRepo.findData(query, {}, options)
    for (let elem of productData) {
        if (userCode && elem.product_id) {
            elem.starred = await favouritesRepo.getCount({ product_id: elem.product_id, user_id: userCode, fav: true })
        } else {
            elem.starred = 0
        }
    }
    return productData
}

const addToFavList = async (body, reqType) => {
    if (!reqType || !['add', 'remove'].includes(reqType)) {
        throw { msg: 'Invalid request received' }
    }
    if (!body || !body.user_id || !body.product_id) {
        throw { msg: 'Incomplete body received' }
    }
    let result
    if (reqType === 'remove') {
        result = await favouritesRepo.updateData({
            product_id: body.product_id,
            user_id: body.user_id,
            fav: true
        }, {
            $set: {
                fav: false
            }
        })
        return { msg: 'Product removed from your favourite list' }
    }
    const exists = await favouritesRepo.findData({
        product_id: body.product_id,
        user_id: body.user_id,
        fav: true
    })
    if (exists && exists.length > 0) {
        return { msg: 'Product already added to your list' }
    }
    result = await favouritesRepo.createData({
        product_id: body.product_id,
        user_id: body.user_id,
        fav: true
    })
    return { msg: `Product added to your favourite list ` }
}

const getProductById = async (productId, userCode) => {
    if (!productId) {
        throw { msg: 'Invalid request received' }
    }
    let productData = await productDataRepo.findData({ product_id: productId })
    if (!productId) {
        throw { msg: 'We are unable to fetch product at this moment. Please contact us' }
    }
    productData = productData[0]
    if (userCode && productData.product_id) {
        productData.starred = await favouritesRepo.getCount({ product_id: productData.product_id, user_id: userCode })
    } else {
        productData.starred = 0
    }
    return productData
}

const addToCart = async (body) => {
    if (!body || !body.user_id || !body.product_id) {
        throw { msg: 'Invalid request detected!' }
    }
    const exists = await favouritesRepo.findData({
        product_id: body.product_id,
        user_id: body.user_id
    })
    const units = body.units ? Number(body.units) : 1
    if (exists && exists.length > 0) {
        await favouritesRepo.updateData({
            product_id: body.product_id,
            user_id: body.user_id
        }, {
            $set: {
                cart: true,
                units
            }
        })
        return { msg: 'Prouct updated in to cart' }
    }
    await favouritesRepo.createData({
        product_id: body.product_id,
        user_id: body.user_id,
        cart: true,
        units
    })
    return { msg: 'Prouct added to cart' }
}

const myCart = async (userCode) => {
    if (!userCode) {
        throw { msg: 'You are not logged into system. Login first' }
    }
    const cartProduct = await favouritesRepo.findData({
        user_id: userCode,
        cart: true
    })
    for (let elem of cartProduct) {
        if (elem && elem.product_id) {
            let productData = await productDataRepo.findData({ product_id: elem.product_id }, {})
            elem = Object.assign(elem, productData[0])
        }
    }
    return cartProduct
}

const removeFromCart = async (favId) => {
    await favouritesRepo.updateData({
        favourite_id: favId
    }, {
        $set: {
            cart: false
        }
    })
    return { msg: 'Product removed from list' }
}

module.exports = {
    searchProduct,
    addToFavList,
    getProductById,
    addToCart,
    myCart,
    removeFromCart
}