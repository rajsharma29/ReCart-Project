'use strict'
const usersRepo = require('../repositories/users')
const productsRepo = require('../repositories/products')
const stripe = require('../config/stripe-handler');
const purchaseHistoryRepo = require('../repositories/purchase-history')
const favouritesRepo = require('../repositories/favourite')

const createStripeCustomer = async (jsonData) => {
    try {
        const customerResponse = await stripe.customers.create(jsonData)
        return customerResponse
    } catch (error) {
        throw error
    }
}

const processPayment = async (body, userCode) => {
    // create customer
    // process payment
    // update favourite collection data
    // add data to purchase history
    let userData = await usersRepo.findData({ user_code: userCode, is_active: true })
    if (!userData || !userData.length === 0) {
        throw { msg: 'No user found with provided request' }
    }
    userData = userData[0]
    let stripeId
    if (!userData.stripe_id) {
        const stripeResponse = await createStripeCustomer({
            name: userData.first_name || 'User',
            email: userData.email,
            description: 'Recart User ' + userData.user_code
        })
        stripeId = stripeResponse.id
        await usersRepo.updateData({ user_code: userCode, is_active: true }, { $set: { stripe_id: stripeId } })
    } else {
        stripeId = userData.stripe_id
    }

    const paymentResponse = await stripe.charges.create({
        source: body.source,
        currency: body.currency,
        amount: body.amount
    })
    for (let elem of body.purchaseList) {
        await purchaseHistoryRepo.createData({
            user_id: userCode,
            product_id: elem.product_id,
            units: elem.units,
            favourite_id: elem.fav_id,
            price_per_unit: elem.price_per_units,
            address_id: body.address_id
        })
        await favouritesRepo.updateData({
            favourite_id: elem.fav_id
        }, {
            $set: {
                cart: false,
                units: 0
            }
        })
    }

    return []
}

module.exports = {
    processPayment
}