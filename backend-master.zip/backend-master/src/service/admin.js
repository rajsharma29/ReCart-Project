'use strict'
const usersRepo = require('../repositories/users')
const utils = require('../utils/utils')
const dateFormat = require('dateformat')
const { JWTAuth } = require('../utils/jwt-auth')
const jwtAuth = new JWTAuth()
const categoriesRepo = require('../repositories/categories')
const cloudinary = require('../config/cloudinary')
const productsRepo = require('../repositories/products')
const paymentHistory = require('../repositories/purchase-history')

/**
 * 1. Check user with same email exists or not
 * 2. If not exits then register
 * 3. If exists then throw error
 */
const register = async (body) => {
    let { name, email, password } = body
    if (!name || !email || !password) { throw { msg: 'Name, Email and Password are required to SignUp' } }
    const userExistCheck = await usersRepo.findData({ email }, { _id: 0, email: 1 })
    if (userExistCheck && userExistCheck.length > 0) {
        throw { msg: 'Provided email is alrady registered. Please login' }
    }
    password = utils.encyptData(password)
    const registerUser = await usersRepo.saveData({ name, email, password, user_role: 'ADMIN' })
    return registerUser
}

/**
 * 1. Check user with provided email is there or not
 * 2. If not, throw error
 * 3. If exists, then check email verified status
 * 4. If 3 failed... then throw error
 * 5. If 3 passed... then check password is matching or not
 * 6. If 5 failed... then throw error
 * 7. If 5 passed... then generate unique token
 * 8. Send final response
 */
const login = async (body) => {
    let { email, password } = body
    if (!email || !password) { throw { msg: 'Email and Password are required to SignIn' } }
    let userData = await usersRepo.findData({ email }, { _id: 0, email: 1, email_verified: 1, password: 1, name: 1, user_role: 1, user_code: 1, is_active: 1 })
    if (!userData || userData.length === 0) {
        throw { msg: 'No any profile found with provided email address' }
    }
    userData = userData[0]
    const passwordFromDb = await utils.decryptData(userData.password)
    if (userData.is_active === false) throw { msg: `This account is temporary disabled. Please contact admin` }
    if (!userData.email_verified) throw { msg: `You haven't verified your email address yet. Please verify` }
    if (password !== passwordFromDb) throw { msg: 'Incorrect password received' }
    const tokenData = {
        email, user_code: userData.user_code, email_status: userData.email_verified, user_role: userData.user_role
    }
    const token = await jwtAuth.createToken(tokenData)
    return { token, user_code: userData.user_code, user_role: userData.user_role }
}

/**
 * 1. Check email is there in db or not
 * 2. If 1 fail ... throw error
 * 3. If 1 pass ... checl account is active or not
 * 4. If account not active... throw error
 * 5. If account not verified then let user know to activate first by resent account activation mail feature
 */
const forgotPassword = async (body) => {
    let { email } = body
    if (!email) throw { msg: 'Email is required to send mail for forgot password request' }
    let userData = await usersRepo.findData({ email }, { _id: 0, email: 1, email_verified: 1, name: 1, user_code: 1, is_active: 1 })
    if (!userData || userData.length === 0) throw { msg: 'No any profile found with provided email address' }
    userData = userData[0]
    if (userData.is_active === false) throw { msg: `This account is temporary disabled. Please contact admin` }
    if (userData.email_verified === false) throw { msg: `Account associated with this email id is not active. Please resent verification link to activate account` }
    // send mail to users
    return true
}

/**
 * 1. check usercode and password provided, if not throw error
 * 2. Encrypt password and update to db
 */
const resetPassword = async (body) => {
    let { userCode, password } = body
    if (!userCode || !password) throw { msg: `Usercode and Password are required to reset password` }
    password = await utils.encyptData(password)
    await usersRepo.updateData({ user_code: userCode, is_active: true }, { $set: { password } })
    return true
}

/**
 * 1. Check email is provided, if not then throw error
 * 2. Check provided email account is there in db or not... If not then throw error
 * 3. If account is already active then no need to send email
 * 4. If account is not active, then send mail
 */
const resendActivation = async (body) => {
    let { email } = body
    if (!email) throw { msg: 'Email is required to send mail for resent account activation request' }
    let userData = await usersRepo.findData({ email }, { _id: 0, email: 1, email_verified: 1, name: 1, user_code: 1, is_active: 1 })
    if (!userData || userData.length === 0) throw { msg: 'No any profile found with provided email address' }
    userData = userData[0]
    if (userData.is_active) throw { msg: `This account is already active. No need to send email again.` }
    // send mail to users
    return true
}

const getUsers = async () => {
    const result = await usersRepo.findData({ user_role: 'END_USER' }, { _id: 0, password: 0, updated_on: 0, })
    for (let elem of result) {
        elem.created_on = dateFormat(elem.created_on, 'dd-mm-yyyy')
    }
    return result
}

const addCategories = async (body) => {
    let { name } = body
    if (!name) { throw { msg: 'Name is required' } }
    const existingData = await categoriesRepo.findData({
        name: { $regex: new RegExp("^" + name.toLowerCase(), "i") }
    })
    if (existingData && existingData.length > 0) {
        throw { msg: 'Category already there with same name' }
    }
    const json = {}
    if (body.name) json.name = body.name
    if (body.parent) json.parent = body.parent
    if (body.type) json.type = body.type
    const result = await categoriesRepo.saveData(json)
    return result
}

const fetchCategories = async () => {
    const allData = await categoriesRepo.findData({ is_active: true }, {
        name: 1, parent: 1, category_id: 1, _id: 0, type: 1
    })
    const parentData = notParentFound(allData)
    for (let singleData of parentData) {
        createOutput(allData, singleData)
    }
    let foodCategories = []
    let ecommerceCategories = []
    for (let elem of parentData) {
        if (elem.type && elem.type === 'food') {
            foodCategories.push(elem)
        } else {
            ecommerceCategories.push(elem)
        }
    }
    return { foodCategories, ecommerceCategories }
}

const createOutput = (data, parentData) => {
    const result = []
    for (let elem of data) {
        if (elem && elem.parent === parentData.category_id) {
            parentData.subChild = parentData.subChild ? parentData.subChild : []
            parentData.subChild.push(elem)
        }
    }
    return parentData
}

const notParentFound = (data) => {
    let response = []
    for (let elem of data) {
        if (!elem.parent) response.push(elem)
    }
    return response
}

const addProduct = async (files, body) => {
    let url
    if (files && files.file && files.file.tempFilePath) {
        const cloudinaryResult = await cloudinary.uploadFile(files.file.tempFilePath)
        if (!cloudinaryResult || !cloudinaryResult.secure_url) {
            throw { msg: 'We are unable to upload file right now. Please contact admin' }
        }
        url = cloudinaryResult.secure_url
    }
    const bodyToSave = generateBodyToSave(body, url)
    const result = await productsRepo.saveData(bodyToSave)
    return result
}

const generateBodyToSave = (body, url) => {
    const json = {}
    json.name = body.productName
    json.description = body.productDescription
    json.parent_cat = body.parentId || ''
    json.sub_cat = body.childId || ''
    json.price_per_unit = Number(body.price_per_unit)
    json.available_stock = Number(body.availableStock)
    json.type = body.type
    if (url) json.picture = url
    return json
}

const fetchAllProducts = async () => {
    const result = await productsRepo.findData({}, {}, {})
    return result
}

const updateProduct = async (body) => {
    const { name, price_per_unit, out_of_stock, is_active, product_id } = body
    if (!name || !price_per_unit || !product_id) {
        throw { msg: 'No any data found to update!' }
    }
    await productsRepo.updateData({ product_id }, { $set: { name, price_per_unit, out_of_stock, is_active } })
    return 'Product Data Updated Successfully!'
}

const getStatastics = async () => {
    const chartQuery = [
        {
            $group: {
                _id: { $month: "$created_on" },
                total: { $sum: 1 },
                amount: { $sum: { $multiply: ["$price_per_unit", "$units"] } }
            }
        }
    ]
    const result = await paymentHistory.aggregateData(chartQuery)
    const paymentData = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    const orderData = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    for (let elem of result) {
        if (elem && elem._id && !isNaN(elem._id)) {
            paymentData[elem._id - 1] = elem.amount
            orderData[elem._id - 1] = elem.total
        }
    }
    return {
        chartData: paymentData,
        orderData
    }
}

module.exports = {
    register, login, forgotPassword, resetPassword, resendActivation,
    getUsers, addCategories,
    fetchCategories, addProduct, fetchAllProducts,
    updateProduct,
    getStatastics
}
