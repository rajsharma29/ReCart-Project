module.exports = {
    MSG_ERROR_SERVER_ERROR: 'Internal Server Error occured'
}