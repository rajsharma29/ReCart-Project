'use strict'
const usersService = require('../service/users')
const logger = require('../middlewares/logger')
const utils = require('../utils/utils')

const register = async (req, res) => {
    try {
        const body = req.body
        const result = await usersService.register(body)
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while user registration', true, error))
    }
}

const login = async (req, res) => {
    try {
        const body = req.body
        const result = await usersService.login(body)
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while user login', true, error))
    }
}

const forgotPassword = async (req, res) => {
    try {
        const body = req.body
        const result = await usersService.forgotPassword(body)
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while forgot password process', true, error))
    }
}

const resetPassword = async (req, res) => {
    try {
        const body = req.body
        const result = await usersService.resetPassword(body)
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while reset password process', true, error))
    }
}

const resendActivation = async (req, res) => {
    try {
        const body = req.body
        const result = await usersService.resendActivation(body)
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while reset password process', true, error))
    }
}

const verifyAccount = async (req, res) => {
    try {
        const userCode = req.query.c
        const result = await usersService.verifyAccount(userCode)
        return res.redirect(result)
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while reset password process', true, error))
    }
}

const getProducts = async (req, res) => {
    try {
        const userCode = req.headers['user_code'] || undefined
        const sF = req.headers['sf'] || "0"
        const result = await usersService.getProducts(userCode, sF)
        return res.send(utils.globalResponse(result, 'Products fetched successfully', false, ''));
    } catch (error) {
        logger.error('Error while getting all products: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while getting all products', true, error))
    }
}

const myProfile = async (req, res) => {
    try {
        const userCode = req.headers['user_code'] || undefined
        const result = await usersService.myProfile(userCode)
        return res.send(utils.globalResponse(result, 'Products fetched successfully', false, ''));
    } catch (error) {
        logger.error('Error while getting all products: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while getting all products', true, error))
    }
}

const changeProfilePicture = async (req, res) => {

    try {
        const files = req.files
        const userCode = req.headers['user_code']
        const result = await usersService.changeProfilePicture(files, userCode)
        // return res.send({ files, body })
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while adding product', true, error))
    }
}

const updateMyProfile = async (req, res) => {
    try {
        const body = req.body
        const userCode = req.params['user_id']
        const result = await usersService.updateMyProfile(body, userCode)
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while adding product', true, error))
    }
}


const updateAddress = async (req, res) => {
    try {
        const body = req.body
        const addressid = req.params['addressId']
        const userCode = req.params['userId']
        const result = await usersService.updateAddress(body, addressid, userCode)
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while adding product', true, error))
    }
}

const purchaseHistory = async (req, res) => {
    try {
        const userCode = req.headers['user_code']
        const result = await usersService.purchaseHistory(userCode)
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while fetching user purchase history', true, error))
    }
}

module.exports = {
    register, login, forgotPassword, resetPassword, resendActivation, verifyAccount,
    getProducts,
    myProfile,
    changeProfilePicture,
    updateMyProfile,
    updateAddress,
    purchaseHistory
}