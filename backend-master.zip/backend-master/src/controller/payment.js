'use strict'
const paymentService = require('../service/payment')
const logger = require('../middlewares/logger')
const utils = require('../utils/utils')

const processPayment = async (req, res) => {
    try {
        const body = req.body
        const userCode = req.headers['user_code']
        const result = await paymentService.processPayment(body, userCode)
        let msg = 'Order places successfully'
        if (result.msg) msg = result.msg
        return res.send(utils.globalResponse(result, msg, false, []))
    } catch (error) {
        logger.error('Error while processing for order: %j %s',error, error)
        return res.send(utils.globalResponse([], 'Error while processing for order', true, error))
    }
}

module.exports = {
    processPayment
}