'use strict'
const adminService = require('../service/admin')
const logger = require('../middlewares/logger')
const utils = require('../utils/utils')

const register = async (req, res) => {
    try {
        const body = req.body
        const result = await adminService.register(body)
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while user registration', true, error))
    }
}

const login = async (req, res) => {
    try {
        const body = req.body
        const result = await adminService.login(body)
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while user login', true, error))
    }
}

const forgotPassword = async (req, res) => {
    try {
        const body = req.body
        const result = await adminService.forgotPassword(body)
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while forgot password process', true, error))
    }
}

const resetPassword = async (req, res) => {
    try {
        const body = req.body
        const result = await adminService.resetPassword(body)
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while reset password process', true, error))
    }
}

const resendActivation = async (req, res) => {
    try {
        const body = req.body
        const result = await adminService.resendActivation(body)
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while resending account activation mail', true, error))
    }
}

const getUsers = async (req, res) => {
    try {
        const result = await adminService.getUsers()
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while fetching all users', true, error))
    }
}


const addCategories = async (req, res) => {
    try {
        const body = req.body
        const result = await adminService.addCategories(body)
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while adding categories', true, error))
    }
}

const fetchCategories = async (req, res) => {
    try {
        const result = await adminService.fetchCategories()
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while reset password process', true, error))
    }
}

const addProduct = async (req, res) => {
    try {
        const files = req.files
        const body = req.body
        const result = await adminService.addProduct(files, body)
        // return res.send({ files, body })
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while adding product', true, error))
    }
}

const fetchAllProducts = async (req, res) => {
    try {
        const result = await adminService.fetchAllProducts()
        return res.send(utils.globalResponse(result, 'Success', false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while fetching all products', true, error))
    }
}

const updateProduct = async (req, res) => {
    try {
        const body = req.body
        const result = await adminService.updateProduct(body)
        return res.send(utils.globalResponse(result, 'Product Data Updated Successfully', false, ''));
    } catch (error) {
        logger.error('Error while updating product data: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while updating product data', true, error))
    }
}

const getStatastics = async (req, res) => {
    try {
        const result = await adminService.getStatastics()
        return res.send(utils.globalResponse(result, 'Stastics Updated Successfully', false, ''));
    } catch (error) {
        logger.error('Error while updating product data: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while feching statastics', true, error))
    }
}

module.exports = {
    register, login, forgotPassword, resetPassword, resendActivation, getUsers,
    addCategories, fetchCategories, addProduct, fetchAllProducts, updateProduct,
    getStatastics
}