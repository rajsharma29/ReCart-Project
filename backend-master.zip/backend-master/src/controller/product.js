'use strict'
const productService = require('../service/product')
const logger = require('../middlewares/logger')
const utils = require('../utils/utils')
const standardApiStructure = require('../middlewares/standard-API-structure-manager')

const searchProduct = async (req, res) => {
    try {
        const sF = req.headers['sf'] || "0"
        const userCode = req.headers['user_code'] || undefined
        const extraParams = standardApiStructure.standardStructureStringToJson(req.query)
        const result = await productService.searchProduct(extraParams, userCode, sF)
        let msg = 'Success'
        if (result && result.msg) msg = result.msg
        return res.send(utils.globalResponse(result, msg, false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while reset password process', true, error))
    }
}

const addToFavList = async (req, res) => {
    try {
        const reqType = req.params['type']
        const body = req.body
        let msg = 'Success'
        const result = await productService.addToFavList(body, reqType)
        if (result && result.msg) msg = result.msg
        return res.send(utils.globalResponse(result, msg, false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while reset password process', true, error))
    }
}

const getProductById = async (req, res) => {
    try {
        const productId = req.params['productId']
        const userCode = req.headers['user_code']
        let msg = 'Success'
        const result = await productService.getProductById(productId, userCode)
        if (result && result.msg) msg = result.msg
        return res.send(utils.globalResponse(result, msg, false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while reset password process', true, error))
    }
}

const addToCart = async (req, res) => {
    try {
        const body = req.body
        let msg = 'Success'
        const result = await productService.addToCart(body)
        if (result && result.msg) msg = result.msg
        return res.send(utils.globalResponse(result, msg, false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while reset password process', true, error))
    }
}

const myCart = async (req, res) => {
    try {
        const userCode = req.headers['user_code'] || undefined
        let msg = 'Success'
        const result = await productService.myCart(userCode)
        if (result && result.msg) msg = result.msg
        return res.send(utils.globalResponse(result, msg, false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while reset password process', true, error))
    }
}

const removeFromCart = async (req, res) => {
    try {
        const favId = req.params['fav_id']
        let msg = 'Success'
        const result = await productService.removeFromCart(favId)
        if (result && result.msg) msg = result.msg
        return res.send(utils.globalResponse(result, msg, false, ''));
    } catch (error) {
        logger.error('Error while user registration: %j %s', error, error)
        if (error && error.msg) {
            return res.status(500).send(utils.globalResponse([], error.msg, true, ''))
        }
        return res.status(500).send(utils.globalResponse([], 'Error while reset password process', true, error))
    }
}


module.exports = {
    searchProduct,
    addToFavList,
    getProductById,
    addToCart,
    myCart,
    removeFromCart
}