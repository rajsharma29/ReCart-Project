'use strict'
const purchaseHistorySchema = require('../models/purchase_history')

const findData = async (query, projection, options) => {
    const dbOperation = await purchaseHistorySchema.find(query, projection, options).lean()
    return dbOperation
}

const createData = async (data) => {
    const dbOperation = await purchaseHistorySchema.create(data)
    return dbOperation
}

const updateData = async (query, updateJson) => {
    const dbOperation = await purchaseHistorySchema.update(query, updateJson)
    return dbOperation
}

const decreaseLimit = async (id) => {
    const dbOperation = await purchaseHistorySchema.updateOne({ imagga_acc_details_id: Number(id) }, { $inc: { available_requests: -1 } })
    return dbOperation
}

const saveData = async (body) => {
    const usersData = new purchaseHistorySchema(body)
    const response = await usersData.save(body)
    return
    response
}
const aggregateData = async (query) => {
    const result = await purchaseHistorySchema.aggregate(query)
    return result
}

module.exports = {
    findData,
    createData,
    updateData,
    decreaseLimit,
    saveData,
    aggregateData
}