'use strict'
const favouritesSchema = require('../models/favourites')

const findData = async (query, projection, options) => {
    const dbOperation = await favouritesSchema.find(query, projection, options).lean()
    return dbOperation
}


const getCount = async (query, projection, options) => {
    const dbOperation = await favouritesSchema.find(query, projection, options).count()
    return dbOperation
}

const createData = async (data) => {
    const dbOperation = await favouritesSchema.create(data)
    return dbOperation
}

const updateData = async (query, updateJson) => {
    const dbOperation = await favouritesSchema.update(query, updateJson)
    return dbOperation
}

const decreaseLimit = async (id) => {
    const dbOperation = await favouritesSchema.updateOne( { imagga_acc_details_id: Number(id) }, { $inc: { available_requests: -1 } })
    return dbOperation
}

const saveData = async (body) => {
    const usersData = new favouritesSchema(body)
    const response = await usersData.save(body)
    return response
}

const deleteData = async (query) => {
    const dbOperation = await favouritesSchema.deleteOne(query)
    return dbOperation
}

module.exports = {
    findData,
    createData,
    updateData,
    decreaseLimit,
    saveData,
    deleteData,
    getCount
}