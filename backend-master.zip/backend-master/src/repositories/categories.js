'use strict'
const categoriesSchema = require('../models/categories')

const findData = async (query, projection, options) => {
    const dbOperation = await categoriesSchema.find(query, projection, options).lean()
    return dbOperation
}

const createData = async (data) => {
    const dbOperation = await categoriesSchema.create(data)
    return dbOperation
}

const updateData = async (query, updateJson) => {
    const dbOperation = await categoriesSchema.update(query, updateJson)
    return dbOperation
}

const decreaseLimit = async (id) => {
    const dbOperation = await categoriesSchema.updateOne( { imagga_acc_details_id: Number(id) }, { $inc: { available_requests: -1 } })
    return dbOperation
}

const saveData = async (body) => {
    const usersData = new categoriesSchema(body)
    const response = await usersData.save(body)
    return response
}

module.exports = {
    findData,
    createData,
    updateData,
    decreaseLimit,
    saveData
}