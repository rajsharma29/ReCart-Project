'use strict'
const productsModel = require('../models/products')

const findData = async (query, projection, options) => {
    const dbOperation = await productsModel.find(query, projection, options).lean()
    return dbOperation
}

const createData = async (data) => {
    const dbOperation = await productsModel.create(data)
    return dbOperation
}

const updateData = async (query, updateJson) => {
    const dbOperation = await productsModel.update(query, updateJson)
    return dbOperation
}

const decreaseLimit = async (id) => {
    const dbOperation = await productsModel.updateOne( { imagga_acc_details_id: Number(id) }, { $inc: { available_requests: -1 } })
    return dbOperation
}

const saveData = async (body) => {
    const usersData = new productsModel(body)
    const response = await usersData.save(body)
    return response
}

const aggregateData = async (query) => {
    const result = await productsModel.aggregate(query)
    return result
}

module.exports = {
    findData,
    createData,
    updateData,
    decreaseLimit,
    saveData,
    aggregateData
}