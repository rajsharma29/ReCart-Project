'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema
const { plugin } = require('mongoose-auto-increment')
const uuid = require('uuid')

const userDetailsSchema = new Schema({
  user_code: {
    type: String,
    default: uuid.v4
  },
  first_name: {
    type: String
  },
  picture: {
    type: String,
    default: 'https://res.cloudinary.com/vipul8896/image/upload/v1586782502/download.png'
  },
  last_name: {
    type: String
  },
  email: {
    type: String,
    required: true
  },
  email_verified: {
    type: Boolean,
    default: false
  },
  user_role: {
    type: String,
    enum: ['END_USER', 'ADMIN', 'UPLOAD_USER'],
    default: 'END_USER'
  },
  contact: {
    type: String
  },
  contact_verified: {
    type: Boolean,
    default: false
  },
  password: {
    type: String,
    required: true
  },
  is_active: {
    type: Boolean,
    default: true
  },
  stripe_id: {
    type: String
  },
  default_address: {
    type: String
  },
  addresses: [{
    address_id: {
      type: String,
      default: uuid.v4
    },
    nickname: String,
    _id: false,
    line1: String,
    line2: String,
    city: String,
    postal: String,
    state: String,
    country: String,
    is_active: {
      type: Boolean,
      default: true
    }
  }],
  is_deleted: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: {
    createdAt: 'created_on',
    updatedAt: 'updated_on'
  },
  collection: 'user_details',
  versionKey: false
})

module.exports = mongoose.model('user_details', userDetailsSchema)
