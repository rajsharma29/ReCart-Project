
'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema
const uuid = require('uuid')

const purchasehistorySchema = new Schema({
    purchase_history_id: {
        type: String,
        default: uuid.v4
    },
    user_id: {
        type: String
    },
    product_id: {
        type: String
    },
    units: {
        type: Number
    },
    favourite_id: {
        type: String
    },
    price_per_unit: {
        type: Number
    },
    address_id: {
        type: String
    },
    is_active: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
  timestamps: {
    createdAt: 'created_on',
    updatedAt: 'updated_on'
  },
  collection: 'purchase_history',
  versionKey: false
})

module.exports = mongoose.model('purchase_history', purchasehistorySchema)
