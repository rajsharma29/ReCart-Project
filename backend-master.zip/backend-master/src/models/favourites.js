'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema
const uuid = require('uuid')

const favouritesSchema = new Schema({
    favourite_id: {
        type: String,
        default: uuid.v4
    },
    product_id: {
        type: String
    },
    user_id: {
        type: String
    },
    fav: {
        type: Boolean
    },
    cart: {
        default: false,
        type: Boolean
    },
    units: {
        type: Number
    },
    is_active: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: {
        createdAt: 'created_on',
        updatedAt: 'updated_on'
    },
    collection: 'favourites',
    versionKey: false
})

// type: 0 added to fav list
// type: 1 added to cart list

module.exports = mongoose.model('favourites', favouritesSchema)
