'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema
const uuid = require('uuid')

const productsSchema = new Schema({
    product_id: {
        type: String,
        default: uuid.v4
    },
    name: {
        type: String
    },
    type: {
        type: String,
        default: "ecommerce",
        enum: ["ecommerce", "food"]
    },
    description: {
        type: String
    },
    parent_cat: {
        type: String
    },
    sub_cat: {
        type: String
    },
    price_per_unit: {
        type: Number,
        default: 0
    },
    out_of_stock: {
        type: Boolean,
        default: false
    },
    available_stock: {
        type: Number,
        default: 10
    },
    currency: {
        type: String,
        default: 'INR'
    },
    picture: {
        type: String,
        default: 'https://res.cloudinary.com/vipul8896/image/upload/v1586782502/download.png'
    },
    is_active: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
  timestamps: {
    createdAt: 'created_on',
    updatedAt: 'updated_on'
  },
  collection: 'products',
  versionKey: false
})

module.exports = mongoose.model('products', productsSchema)
