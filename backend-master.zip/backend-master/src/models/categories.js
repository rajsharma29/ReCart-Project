'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema
const uuid = require('uuid')

const categoriesSchema = new Schema({
    category_id: {
        type: String,
        default: uuid.v4
    },
    type: {
        type: String,
        default: "ecommerce",
        enum: ["ecommerce", "food"]
    },
    name: {
        type: String
    },
    parent: {
        type: String
    },
    is_active: {
        type: Boolean,
        default: true
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: {
        createdAt: 'created_on',
        updatedAt: 'updated_on'
    },
    collection: 'categories',
    versionKey: false
})

module.exports = mongoose.model('categories', categoriesSchema)
