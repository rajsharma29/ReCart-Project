import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainDashboardComponent } from './Dashboard/main-dashboard/main-dashboard.component';
import { LoginComponent } from './Auth/login/login.component';
import { RegisterComponent } from './Auth/register/register.component';
import { MyCartComponent } from './Dashboard/my-cart/my-cart.component';
import { MyProfileComponent } from './Dashboard/my-profile/my-profile.component';
import { ForgotPasswordComponent } from './Auth/forgot-password/forgot-password.component';
import { AboutUsComponent } from './Dashboard/about-us/about-us.component';
import { ContactUsComponent } from './Dashboard/contact-us/contact-us.component';
import { LandingPageComponent } from './Dashboard/landing-page/landing-page.component';
import { PurchaseHistoryComponent } from './Dashboard/purchase-history/purchase-history.component';


// { path: '', redirectTo: '', pathMatch: 'full' },
const routes: Routes = [
  { path: '', component: LandingPageComponent, pathMatch: 'full' },
  { path: 'dashboard', component: MainDashboardComponent, pathMatch: 'full' },
  { path: 'login', component: LoginComponent, pathMatch: 'full' },
  { path: 'register', component: RegisterComponent, pathMatch: 'full' },
  { path: 'forgot-password', component: ForgotPasswordComponent, pathMatch: 'full' },
  { path: 'dashboard/cart', component: MyCartComponent, pathMatch: 'full' },
  { path: 'dashboard/profile', component: MyProfileComponent, pathMatch: 'full' },
  { path: 'about-us', component: AboutUsComponent, pathMatch: 'full' },
  { path: 'contact-us', component: ContactUsComponent, pathMatch: 'full' },
  { path: 'dashboard/purchase', component: PurchaseHistoryComponent, pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
