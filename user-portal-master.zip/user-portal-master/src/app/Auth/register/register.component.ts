import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GeneralService } from 'src/app/core/general.service';
import { UtilsService } from 'src/app/core/utils.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  public firstName
  public emailId
  public password

  constructor(private router: Router,
    public utilsService: UtilsService,
    public generalSerice: GeneralService) { }

  ngOnInit() {
    sessionStorage.clear()
  }

  validateEmail(email) {
    if (!email) return false
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  }

  goToScreen(path) {
    this.router.navigate([path])
  }

  signUp() {
    if (!this.emailId || !this.firstName || !this.password) {
      this.utilsService.showMessage('error', 'Error', 'Please enter all the details')
      return true
    }
    if (!this.validateEmail(this.emailId)) {
      this.utilsService.showMessage('error', 'Error', 'Please enter valid email address')
      return true;
    }
    const json = {
      first_name: this.firstName,
      email: this.emailId,
      password: this.password
    }
    this.utilsService.enableLoading = true;
    this.generalSerice.registerAPICall(json).subscribe((response) => {
      this.router.navigate(['/login'])
      this.utilsService.enableLoading = false;
      this.utilsService.showMessage('success', 'Success', 'Your are registered successfully!')
    }, (error) => {
      this.utilsService.enableLoading = false;
      this.utilsService.showMessage('error', 'Error', 'We are facing issue while your registration. Please contact us')
    })
  }

}
