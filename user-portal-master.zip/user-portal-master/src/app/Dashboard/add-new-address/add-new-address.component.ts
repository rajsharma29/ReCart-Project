import { Component, OnInit, Inject } from '@angular/core';
import { DialogData } from '../main-dashboard/main-dashboard.component';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { UtilsService } from 'src/app/core/utils.service';
import { GeneralService } from 'src/app/core/general.service';

@Component({
  selector: 'app-add-new-address',
  templateUrl: './add-new-address.component.html',
  styleUrls: ['./add-new-address.component.scss']
})
export class AddNewAddressComponent implements OnInit {

  public line1
  public line2
  public city
  public zipCode
  public state
  public country
  public nickname

  constructor(
    public dialogRef: MatDialogRef<AddNewAddressComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private utilsService: UtilsService,
    private generalService: GeneralService
  ) { }

  ngOnInit() {
  }

  addAddress() {
    if (!this.line1 || !this.city || !this.zipCode || !this.state || !this.country) {
      this.utilsService.showMessage('info', 'Info', 'Please file all details')
      return true
    }
    if (!this.nickname) this.nickname = this.city
    const json = {
      addresses: {
        line1: this.line1,
        line2: this.line2 || "",
        city: this.city,
        postal: this.zipCode,
        state: this.state,
        country: this.country,
        nickname: this.nickname
      }
    }
    this.utilsService.enableLoading = true;
    this.generalService.updateProfile(json).subscribe((response) => {
      this.utilsService.enableLoading = false;
      this.dialogRef.close()
    }, (error) => {
      this.utilsService.enableLoading = false;
    })
  }

}
