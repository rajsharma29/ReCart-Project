import { Component, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { GeneralService } from 'src/app/core/general.service';
import { UtilsService } from 'src/app/core/utils.service';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { DialogData } from '../main-dashboard/main-dashboard.component';
import { MatRadioChange } from '@angular/material/radio';

@Component({
  selector: 'app-my-cart',
  templateUrl: './my-cart.component.html',
  styleUrls: ['./my-cart.component.scss']
})
export class MyCartComponent implements OnInit {

  public cartList
  public totalAmount
  public selectedDelieveryAddress

  constructor(
    private router: Router,
    private generalService: GeneralService,
    private utilService: UtilsService,
    private addressDialog: MatDialog
  ) { }

  ngOnInit() {
    const isLoggedIn = sessionStorage.getItem('isLoggedIn')
    if (isLoggedIn !== 'true') {
      this.router.navigate(['/login'])
    } else {
      this.getCartList();
    }
  }

  getCartList() {
    // this.utilService.enableLoading = true;
    this.generalService.myCartList().subscribe((response: any) => {
      // this.utilService.enableLoading = false;
      this.cartList = response.data || []
      this.countTotalAmount()
    }, (error: any) => {
      // this.utilService.enableLoading = false;
    })
  }

  plusMinus(data, index, type) {
    if (type === 'plus') {
      if (this.cartList[index]['units'] < this.cartList[index]['available_stock']) {
        this.cartList[index]['units'] = this.cartList[index]['units'] + 1
      } else {
        this.utilService.showMessage('info', 'Info', `We have only ${this.cartList[index]['available_stock']} units available`)
      }
    }

    if (type === 'minus' && this.cartList[index]['units'] !== 1) {
      this.cartList[index]['units'] = this.cartList[index]['units'] - 1
    }
    this.countTotalAmount()

    this.utilService.enableLoading = true;
    const json = {
      product_id: data.product_id,
      user_id: sessionStorage.getItem('user_code'),
      units: this.cartList[index]['units']
    }
    this.generalService.addToCart(json).subscribe((response) => {
      this.utilService.enableLoading = false;
      return true;
    }, (error) => {
      this.utilService.enableLoading = false;
      return true;
    })
  }

  countTotalAmount() {
    let sum = 0
    for (let elem of this.cartList) {
      sum = sum + (elem.units * elem.price_per_unit)
    }
    this.totalAmount = sum;
  }

  removeFromCart(data) {
    this.utilService.enableLoading = true;
    this.generalService.removeFromCart(data.favourite_id).subscribe((response: any) => {
      this.utilService.enableLoading = false;
      this.getCartList()
      return true;
    }, (error: any) => {
      this.utilService.enableLoading = false;
      return true;
    })
  }

  getFinalPurchaseList() {
    const response = []
    for (let elem of this.cartList) {
      const json = {}
      json['fav_id'] = elem.favourite_id
      json['units'] = elem.units
      json['price_per_units'] = elem.price_per_unit
      json['product_id'] = elem.product_id
      response.push(json)
    }
    return response
  }

  processPaymentApiCall(data) {
    this.utilService.enableLoading = true;
    this.generalService.processPayment(data).subscribe((response) => {
      this.utilService.enableLoading = false;
      this.getCartList()
      this.utilService.showMessage('success', 'Success', 'Your order placed successfully!')
    }, (error) => {
      this.utilService.enableLoading = false;
      this.utilService.showMessage('error', 'Error', 'We are facing issue while placing your order. Please contact us.')
    })
  }

  openCheckout() {

    if (!this.selectedDelieveryAddress) {
      this.utilService.showMessage('info', 'Info', 'Please select delievery address first')
      this.selectDelieveryAddress()
      return true;
    }

    var self = this
    var handler = (<any>window).StripeCheckout.configure({
      key: 'pk_test_TtcllVCNkTBShCVnLo2XKtca00MDmzLykg',
      locale: 'auto',
      image: '../../../assets/recart.png',
      token: function (token: any) {
        const purchaseList = self.getFinalPurchaseList()
        const json = {
          currency: 'inr',
          source: token.id,
          amount: self.totalAmount * 100,
          purchaseList: purchaseList,
          address: self.selectedDelieveryAddress
        }
        self.processPaymentApiCall(json)
      }
    });

    handler.open({
      name: 'ReCart',
      description: 'ReCart - Shopping',
      amount: this.totalAmount * 100,
      currency: 'inr',
      email: sessionStorage.getItem('email')
    });
  }

  selectDelieveryAddress() {
    const dialogRef = this.addressDialog.open(SelectDelieveryAddressDialog, {
      width: '500px',
      height: '540px',
      data: { id: this.selectedDelieveryAddress }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.selectedDelieveryAddress = result
    });
  }
}

@Component({
  selector: 'selectAddress',
  templateUrl: 'addresses-list.html',
})
export class SelectDelieveryAddressDialog implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<SelectDelieveryAddressDialog>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private utilsService: UtilsService,
    private generalService: GeneralService,
    public router: Router) { }

  public defaultAddress = this.data['id'] ? this.data['id'] : ''
  public addresses = []

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit() {
    this.getAddress()
  }

  getAddress() {
    this.generalService.myProfile().subscribe((response) => {
      if (this.defaultAddress === '') this.defaultAddress = response.data.default_address
      let data = response.data.addresses
      for (let elem of data) {
        if (elem.is_active === true) {
          this.addresses.push(elem)
        }
      }
    }, (error) => {

    })
  }

  onChange(mrChange: MatRadioChange) {
    this.defaultAddress = mrChange.value
    this.data = mrChange.value
  }

  goToMyProfile() {
    this.dialogRef.close();
    this.router.navigate(['dashboard/profile'])
  }

}
