import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GeneralService } from 'src/app/core/general.service';
import { UtilsService } from 'src/app/core/utils.service';

@Component({
  selector: 'app-purchase-history',
  templateUrl: './purchase-history.component.html',
  styleUrls: ['./purchase-history.component.scss']
})
export class PurchaseHistoryComponent implements OnInit {

  public purchaseHistory: any;

  constructor(
    private router: Router,
    private generalService: GeneralService,
    private utilsService: UtilsService
  ) { }

  async ngOnInit() {
    const isLoggedIn = sessionStorage.getItem('isLoggedIn')
    if (isLoggedIn !== 'true') {
      this.utilsService.showMessage('info', 'Info', 'You have not logged into the system. Please login first')
      this.router.navigate([''])
    }
    await this.getPurchaseHistoryData()
  }

  getPurchaseHistoryData() {
    this.utilsService.enableLoading = true;
    this.generalService.getPurchaseHistory().subscribe((response: any) => {
      this.utilsService.enableLoading = false;
      this.purchaseHistory = response.data || []
    }, (error: any) => {
      this.utilsService.enableLoading = false;
      this.utilsService.showMessage('error', 'Error', 'We are facing issue to fetch your data. Please contact us!')
    })
  }


}
