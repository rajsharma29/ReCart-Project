import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UtilsService } from 'src/app/core/utils.service';
import { GeneralService } from 'src/app/core/general.service';
import { MatDialog } from '@angular/material/dialog';
import { AddNewAddressComponent } from '../add-new-address/add-new-address.component';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss']
})
export class MyProfileComponent implements OnInit {

  public section = 1
  public myProfile
  public formData = new FormData();

  constructor(public router: Router,
    private utilService: UtilsService,
    private generalService: GeneralService,
    public newAddressDialog: MatDialog) { }

  async ngOnInit() {
    const loggedIn = sessionStorage.getItem('isLoggedIn')
    if (!loggedIn || loggedIn === 'false') {
      this.router.navigate(['/login'])
    } else {
      await this.getProfileData();
    }
  }

  getProfileData() {
    this.utilService.enableLoading = true;
    this.generalService.myProfile().subscribe((response) => {
      this.myProfile = response.data || []
      this.utilService.enableLoading = false;
    }, (error) => {
      this.utilService.enableLoading = false;
    })
  }

  logmeout() {
    sessionStorage.clear()
    this.router.navigate(['/dashboard'])
  }

  actvieSession(id) {
    this.section = id
  }

  uploadProfilePicture(file) {
    if (!file) { return true }
    this.utilService.enableLoading = true;
    this.formData.set('file', file[0], file.name);
    this.generalService.changeProfilePicture(this.formData).subscribe((response) => {
      this.formData.delete('file')
      this.myProfile.picture = response.data
      this.utilService.enableLoading = false;
    }, (error) => {
      this.formData.delete('file')
      this.utilService.enableLoading = false;
    })
  }

  addAddress() {
    const newAddressDialogRef = this.newAddressDialog.open(AddNewAddressComponent, {
      width: '450px',
      height: '500px',
      data: []
    })

    newAddressDialogRef.afterClosed().subscribe(result => {
      this.getProfileData()
    });
  }

  goToScreen(link) {
    this.router.navigate([link])
  }

  setDefaultAddress(addressId) {
    if (!addressId) {
      return true
    }
    const json = {
      default_address: addressId
    }
    this.generalService.updateProfile(json).subscribe((response: any) => {
      this.myProfile.default_address = addressId
    }, (error: any) => {

    })
  }

  updateAddress(addressId, index) {
    this.generalService.updateAddress({ is_active: false }, addressId).subscribe((response) => {
      this.myProfile.addresses.map((item, index) => {
        if (item.address_id === addressId) {
          this.myProfile.addresses.splice(index, 1)
        }
      })
    }, (error) => {

    })
  }

}
