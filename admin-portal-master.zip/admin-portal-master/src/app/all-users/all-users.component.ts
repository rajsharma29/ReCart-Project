import { Component, OnInit } from '@angular/core';
import { UtilsService } from 'src/core/utils.service';
import { GeneralService } from 'src/core/general.service';
import { ToasterService } from 'angular2-toaster';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-all-users',
  templateUrl: './all-users.component.html',
  styleUrls: ['./all-users.component.scss']
})
export class AllUsersComponent implements OnInit {

  public usersData
  public displayedColumns = ["name", "email", "email_verified", "registered_on"]

  constructor(public utilService: UtilsService,
    private generalService: GeneralService,
    private toasterService: ToasterService) { }

  async ngOnInit() {
    this.utilService.loggedIn = true;
    await this.getAllUsers()
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.usersData.filter = filterValue.trim().toLowerCase();
  }

  getAllUsers() {
    this.utilService.enableLoading = true;
    this.generalService.getAllUsers().subscribe((response: any) => {
      this.utilService.enableLoading = false;
      this.usersData = new MatTableDataSource(response.data)
    }, (error: any) => {
      this.utilService.enableLoading = false;
      this.toasterService.pop('error', 'Error', 'Something went wrong while fetching users list')
    })
  }

  removeUser(userCode) {
  }
}
