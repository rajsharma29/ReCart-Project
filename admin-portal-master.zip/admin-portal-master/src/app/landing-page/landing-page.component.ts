import { Component, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { GeneralService } from 'src/core/general.service';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss']
})
export class LandingPageComponent implements OnInit {


  public paymentData 
  public ChartDataSets
  public showGrapth = false
  public lineChartData
  public lineChartData2
  public orderData

  constructor(
    private generalService: GeneralService
  ) { }

  ngOnInit() {
    this.getData()
  }

  getData() {
    this.generalService.getStatastics().subscribe((response) => {
      this.paymentData = response.data.chartData || [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      this.orderData = response.data.orderData || [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      this.lineChartData = [
        { data: this.paymentData, label: 'Payment Received' }
      ];
      this.lineChartData2 = [
        { data: this.orderData, label: 'Order Track' },
      ];
      this.showGrapth = true;
    }, (error) => {

    })
  }

  

  lineChartLabels: Label[] = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  lineChartOptions = {
    responsive: true,
    scaleStartValue: 200
  };

  lineChartColors: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: '#1976d2',
    },
  ];
  lineChartLegend = true;
  lineChartPlugins = [];
  lineChartType = 'line';
}
