import { Component, OnInit } from '@angular/core';
import { UtilsService } from 'src/core/utils.service';
import { GeneralService } from 'src/core/general.service';
import { ToasterService } from 'angular2-toaster';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss']
})
export class AddProductComponent implements OnInit {

  public allParentCat
  public allChildCat
  public selectedParentCatId
  public selectedChildCatId
  public productName = new FormControl()
  public productDescription = new FormControl()
  public productImage = new FormControl()
  public availableStocks = new FormControl()
  public pricePerUnit = new FormControl()
  public accept = 'image/*'
  public formData = new FormData();

  public config = {
    toolbar: {
      container: [
        ['bold', 'italic', 'underline', 'strike'],        
        ['code-block'],
        [{ 'header': 1 }, { 'header': 2 }],               
        [{ 'list': 'ordered' }, { 'list': 'bullet' }],
        [{ 'script': 'sub' }, { 'script': 'super' }],     
        [{ 'indent': '-1' }, { 'indent': '+1' }],         
        [{ 'direction': 'rtl' }],                         
        [{ 'size': ['small', false, 'large', 'huge'] }],  
        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
        [{ 'font': [] }],
        [{ 'align': [] }],
        ['clean']
      ]
    }
  }

  public editorStyle = {
    height: '200px'
  }

  constructor(
    private utilsService: UtilsService,
    private generalService: GeneralService,
    private toasterService: ToasterService
  ) { }

  async ngOnInit() {
    await this.getAllCat()
  }

  changeImage(file) {
    this.formData.set('file', file[0], file.name);
  }

  addProduct() {
    if (!this.productName.value || !this.selectedParentCatId || !this.availableStocks.value || !this.pricePerUnit.value) {
      this.toasterService.pop('error', 'Error', 'Please add Product Name, Parent Category, Available Stocks and Price Per Unit')
      return true;
    }
    this.formData.set('productName', this.productName.value)
    if (this.productDescription.value) this.formData.set('productDescription', JSON.stringify(this.productDescription.value))
    this.formData.set('parentId', this.selectedParentCatId)
    if (this.selectedChildCatId) this.formData.set('childId', this.selectedChildCatId)
    this.formData.set('availableStock', this.availableStocks.value)
    this.formData.set('price_per_unit', this.pricePerUnit.value)
    this.utilsService.enableLoading = true;
    this.generalService.addProduct(this.formData).subscribe((response: any) => {
      this.formData.delete('productName')
      this.formData.delete('parentId')
      this.formData.delete('availableStock')
      this.formData.delete('price_per_unit')
      this.formData.delete('file')
      this.productName.setValue('')
      this.productDescription.setValue('')
      this.availableStocks.setValue('')
      this.pricePerUnit.setValue('')
      this.toasterService.pop('success', 'Success', 'Product added successfully!')
      this.utilsService.enableLoading = false;
    }, (error: any) => {
      this.utilsService.enableLoading = false;
      let msg = 'Error while adding product'
      if (error && error.error && error.error.message) msg = error.error.message
      this.toasterService.pop('error', 'Error', msg)
    })
  }

  getAllCat() {
    this.generalService.getAllCategoris().subscribe((response: any) => {
      this.allParentCat = response.data || []
    }, (error: any) => {
      this.toasterService.pop('error', 'Error', 'Error while fetching categories')
    })
  }

  selectParentCat(value) {
    this.allChildCat = value.subChild
    this.selectedParentCatId = value.category_id
  }

  selectChildCat(value) {
    this.selectedChildCatId = value.category_id
  }

}
