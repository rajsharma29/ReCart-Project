import { Component, OnInit } from '@angular/core';
import { UtilsService } from 'src/core/utils.service';
import { GeneralService } from 'src/core/general.service';
import { ToasterService } from 'angular2-toaster';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { MatRadioChange } from '@angular/material/radio';


@Component({
  selector: 'app-manage-categories',
  templateUrl: './manage-categories.component.html',
  styleUrls: ['./manage-categories.component.scss']
})
export class ManageCategoriesComponent implements OnInit {

  myControl = new FormControl();
  subCategory = new FormControl();
  subFoodCategory = new FormControl();
  public allCats
  public selectedParentId
  public selectedParentFoodId
  public foodType = "VEG"

  constructor(
    private utilsService: UtilsService,
    private generalService: GeneralService,
    private toasterService: ToasterService
  ) { }

  async ngOnInit() {
    await this.getAllCat()
  }

  getAllCat() {
    this.utilsService.enableLoading = true;
    this.generalService.getAllCategoris().subscribe((response: any) => {
      this.utilsService.enableLoading = false;
      this.allCats = response.data || []
    }, (error: any) => {
      this.utilsService.enableLoading = false;
      this.toasterService.pop('error', 'Error', 'Error while fetching categories')
    })
  }

  addParentCat(type) {
    if (!this.myControl.value) {
      this.toasterService.pop('error', 'Error', 'Please enter category name')
      return true;
    }
    this.utilsService.enableLoading = true;
    const json = {}
    json['name'] = this.myControl.value;
    if (type === '2') json['type'] = 'food'
    this.generalService.saveCategories(json).subscribe((response: any) => {
      this.utilsService.enableLoading = false;
      this.getAllCat();
      this.myControl.setValue('')
    }, (error: any) => {
      this.utilsService.enableLoading = false;
      let msg = 'We are unable to save category at this moment'
      if (error && error.error && error.error.message) msg = error.error.message
      this.toasterService.pop('error', 'Error', msg)
    })
  }

  addSubCategory() {
    if (!this.selectedParentId || !this.subCategory.value) {
      this.toasterService.pop('error', 'Error', 'Please select parent category and add sub category name')
      return true;
    }
    this.utilsService.enableLoading = true;
    const json = {}
    json['name'] = this.subCategory.value;
    json['parent'] = this.selectedParentId;
    this.generalService.saveCategories(json).subscribe((response: any) => {
      this.utilsService.enableLoading = false;
      this.getAllCat();
      this.subCategory.setValue('')
    }, (error: any) => {
      this.utilsService.enableLoading = false;
      let msg = 'We are unable to save category at this moment'
      if (error && error.error && error.error.message) msg = error.error.message
      this.toasterService.pop('error', 'Error', msg)
    })
  }

  addFoodCategory() {
    if (!this.selectedParentFoodId || !this.subFoodCategory.value) {
      this.toasterService.pop('error', 'Error', 'Please select parent category and add sub category name')
      return true;
    }
    this.utilsService.enableLoading = true;
    const json = {}
    json['name'] = this.subFoodCategory.value;
    json['parent'] = this.selectedParentFoodId;
    json['type'] = "food"
    this.generalService.saveCategories(json).subscribe((response: any) => {
      this.utilsService.enableLoading = false;
      this.getAllCat();
      this.subFoodCategory.setValue('')
    }, (error: any) => {
      this.utilsService.enableLoading = false;
      let msg = 'We are unable to save category at this moment'
      if (error && error.error && error.error.message) msg = error.error.message
      this.toasterService.pop('error', 'Error', msg)
    })
  }

  selectedParent(id) {
    this.selectedParentId = id
  }
  selectedParentFood(id) {
    this.selectedParentFoodId = id
  }

  onChange(mrChange: MatRadioChange) {
    this.foodType = mrChange.value
  }

}
