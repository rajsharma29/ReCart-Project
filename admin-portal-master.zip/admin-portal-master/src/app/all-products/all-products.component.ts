import { Component, OnInit, Inject } from '@angular/core';
import { UtilsService } from 'src/core/utils.service';
import { GeneralService } from 'src/core/general.service';
import { ToasterService } from 'angular2-toaster';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';


export interface DialogData {
}

@Component({
  selector: 'app-all-products',
  templateUrl: './all-products.component.html',
  styleUrls: ['./all-products.component.scss']
})
export class AllProductsComponent implements OnInit {

  public allProductsData
  animal: string;
  name: string;

  constructor(
    private utilsService: UtilsService,
    private generalService: GeneralService,
    private toasterService: ToasterService,
    public dialog: MatDialog
  ) { }

  async ngOnInit() {
    await this.getAllProducts()
  }

  getAllProducts() {
    this.generalService.getAllProduct().subscribe((response: any) => {
      this.allProductsData = response.data
    }, (error: any) => {
      let msg = 'Error while getting all products'
      if (error && error.error && error.error.message) msg = error.error.message
      this.toasterService.pop('error', 'Error', msg)
    })
  }

  editProduct(productId, index) {
    const dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: '500px',
      height: '500px',
      data: productId
    });

    dialogRef.afterClosed().subscribe(result => {
      this.getAllProducts()
    });
  }

}

@Component({
  selector: 'dialog',
  templateUrl: 'dialog.html',
})
export class DialogOverviewExampleDialog {

  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialog>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private utilsService: UtilsService,
    private generalService: GeneralService,
    private toasterService: ToasterService) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

  updateData(data) {
    const json = {}
    json['name'] = data.name
    json['price_per_unit'] = data.price_per_unit
    json['out_of_stock'] = data.out_of_stock
    json['is_active'] = data.is_active
    json['product_id'] = data.product_id
    this.generalService.updateProductData(json).subscribe((response: any) => {
      this.onNoClick();
      this.toasterService.pop('success', 'Success', 'Product data updated successfully')
    }, (error: any) => {
      let msg = 'Error while updating product data'
      if (error && error.error && error.error.message) msg = error.error.message
      this.toasterService.pop('error', 'Error', msg)
    })
  }

  changed(data) {
  }

}